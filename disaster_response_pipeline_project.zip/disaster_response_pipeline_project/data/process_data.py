import sys
import pandas as pd
from sqlalchemy import create_engine


def load_data(messages_filepath, categories_filepath):
    """
    Carica i dati dai file CSV.

    Parameters:
    messages_filepath (str): Percorso del file CSV dei messaggi.
    categories_filepath (str): Percorso del file CSV delle categorie.

    Returns:
    pandas.DataFrame: DataFrame contenente i dati dei messaggi.
    pandas.DataFrame: DataFrame contenente i dati delle categorie.
    """
    messages = pd.read_csv(messages_filepath)
    categories = pd.read_csv(categories_filepath)
    return messages, categories


def clean_data(df, categories):
    """
    Pulisce il dataset.

    Parameters:
    df (pandas.DataFrame): DataFrame principale.
    categories (pandas.DataFrame): DataFrame delle categorie.

    Returns:
    pandas.DataFrame: DataFrame pronto per l'analisi.
    """
    # Creazione del dataframe delle categorie
    categories = pd.concat([categories, categories['categories'].str.split(';', expand=True)], axis=1)
    row = categories.iloc[0]
    category_colnames = row.apply(lambda x: x.split('-')[0])
    categories.columns = category_colnames

    # Conversione delle colonne da stringa a numerico
    for column in categories.columns:
        categories[column] = categories[column].astype(str).str[-1]
        categories[column] = pd.to_numeric(categories[column], errors='coerce')

    # Sostituzione delle colonne 'categories' nel dataframe principale
    df = pd.concat([df, categories], axis=1)
    df = df.drop('categories', axis=1)

    # Rimozione dei duplicati
    duplicates_before = df.duplicated().sum()
    print("Number of duplicates before removal:", duplicates_before)
    df = df.drop_duplicates()
    print(df.columns)

    df = df.loc[:, ~df.columns.duplicated()]
    print(df.columns)

    df = df.drop(['2', 'related'], axis=1)
    duplicates_after = df.duplicated().sum()
    print("Number of duplicates after removal:", duplicates_after)

    return df


def save_data(df, database_filename):
    """
    Salva il DataFrame in un database SQLite.

    Parameters:
    df (pandas.DataFrame): DataFrame da salvare.
    database_filename (str): Nome del file del database SQLite.
    """
    engine = create_engine('sqlite:///' + database_filename)
    df.to_sql('samtable', engine, index=False, if_exists='replace')

def main():
    if len(sys.argv) == 4:
        messages_filepath, categories_filepath, database_filepath = sys.argv[1:]

        print('Loading data...\n    MESSAGES: {}\n    CATEGORIES: {}'
              .format(messages_filepath, categories_filepath))
        messages, categories = load_data(messages_filepath, categories_filepath)

        print('Cleaning data...')
        df = clean_data(messages, categories)

        print('Saving data...\n    DATABASE: {}'.format(database_filepath))
        save_data(df, database_filepath)

        print('Cleaned data saved to database!')
    else:
        print('Please provide the filepaths of the messages and categories '
              'datasets as the first and second argument respectively, as '
              'well as the filepath of the database to save the cleaned data '
              'to as the third argument. \n\nExample: python process_data.py '
              'disaster_messages.csv disaster_categories.csv '
              'DisasterResponse.db')


if __name__ == '__main__':
    main()
